# Antoci — landing page (Proposta A "Materia → Forma")

Sito single-page per **Antoci**, studio di scultura e design a Ragusa, Sicilia.
Instagram: **@antocisculptures** (bio: "Unique pieces, crafted on commission · Proudly made in Sicily · Objects for meaningful spaces").

`index.html` è autonomo: HTML + CSS + JS inline, nessuna dipendenza. Usa solo Google Fonts (Barlow, Cormorant Garamond per il logo) e le immagini nella cartella `img/`.

## Struttura della pagina (in ordine)
1. **Header** su panna (#EFEDE8): logo "antocı" centrato e nav sotto (Work, Studio, Material, Contact). Da mobile: logo a sinistra e a destra solo le tre lineette, senza bordo né sfondo. Il menu si apre a tutto schermo, con le voci allineate a destra e centrate in verticale.
2. **Immagine di apertura** a tutta larghezza (`img/hero_ig.jpg`, presa dal post Instagram "Matter before form", logo rimosso). Da mobile occupa circa 1/3 dello schermo (30svh).
3. **Indice dei 3 progetti** su nero #141414: "→ NOME / sottotitolo". Da desktop uno a sinistra, uno al centro e uno a destra; sotto i 1100px in colonna. Ogni link scorre al progetto.
4. **Stacco** su grigio carbone #1F1F1D, appena più chiaro del nero: "Ideas shaped into matter." + 3 progetti (Miles Craigwell / Audemars Piguet / Converse).
   - Desktop: griglia a 3 colonne, foto 4:5, nome in alto a destra, piccoli dettagli in basso.
   - Mobile: slider orizzontale con lo swipe (scroll-snap), senza pulsanti. Solo il nome in alto a destra, un po' più grande; niente numerini o testi in basso.
5. **The studio** su panna: testo + elenco "What we create".
6. **Material & craft** su nero: testo + 4 rettangoli 3:2. Nessun effetto hover: 4 foto fisse (attrezzi su trucioli, scanalature fatte a mano, gesso, mano con scalpello sul marmo, da Instagram). Sotto l'elenco WOOD CERAMIC STONE MARBLE c'è una linea divisoria lunga esattamente quanto il testo, dalla W alla E. Da mobile: solo 3 foto (scanalature, gesso, marmo; gli attrezzi su trucioli sono nascosti), rettangolari, impilate in verticale senza spazio tra loro, più piccole (94% della larghezza, max 400px, centrate, formato 2.85:1, quindi basse).
7. **Contact** su panna, poi footer nero.

## Decisioni già prese con il cliente (NON cambiarle)
- Colori: panna sporco #EFEDE8 / nero #141414 / stacco #1F1F1D. Niente marrone.
- Font: sans maiuscolo spaziato per titoli ed etichette, stesso font in minuscolo e leggero per le descrizioni. **La "I" maiuscola deve essere a bastoncino, senza grazie**: per questo NON usare font monospaziati (hanno tutti la I con le stanghette). Font scelto: **Barlow** (approvato).
- Logo "antocı" in serif minuscolo (Cormorant Garamond), con la i senza puntino come nel logo reale.
- Vietato:
  - trattini decorativi e "—" nei testi;
  - link enormi in corsivo serif;
  - griglie di materiali con riquadri segnaposto vuoti;
  - qualsiasi effetto hover che cambia immagine (né sui progetti né sui materiali);
  - effetti "luce che segue il cursore";
  - gallerie con spazi tra le foto;
  - il logo "antoci" stampato sulle foto.
- Testi in inglese, presi dal copy fornito dal cliente. Non inventare clienti, materiali o numeri.

## Da fare
- **Immagine di apertura:** ora è 1404px, presa da Instagram. Al centro resta un'ombra leggera dove stava il logo. Se arriva il file originale dall'archivio, sostituirla.
- **Contatti:** email, telefono e Instagram reali al posto di [Email] [Phone] [Instagram].
- **Progetto 1:** la foto è il jersey in legno per Miles Craigwell (pulita dalle scritte di Instagram). Va confermato col cliente il nome da mostrare.
- **Altri progetti su Instagram, da aggiungere se servono:** DAARK Paris (tazza in gesso trompe-l'oeil), Moncler × Salehe Bembury, "A surface built one line at a time".
- **Immagini dei materiali:** sostituire con foto ad alta risoluzione dall'archivio del cliente, che ha promesso di mandarle.
- **Dominio e hosting:** gestiti da Juan (dominio tipo antoci.studio). Il sito va pubblicato come statico.
